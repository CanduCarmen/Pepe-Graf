---
aliases: [IsraelBoss]
tags: [minecraft, player]
connections: 2
namemc: https://namemc.com/profile/IsraelBoss.1
---

# IsraelBoss

[IsraelBoss](https://namemc.com/profile/IsraelBoss.1)

