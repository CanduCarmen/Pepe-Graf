---
aliases: [_Socrate]
tags: [minecraft, player]
connections: 1
namemc: https://namemc.com/profile/_Socrate.1
---

# _Socrate

[_Socrate](https://namemc.com/profile/_Socrate.1)

