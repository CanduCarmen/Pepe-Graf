---
aliases: [_Pntr1]
tags: [minecraft, player]
connections: 4
namemc: https://namemc.com/profile/_Pntr1.1
---

# _Pntr1

[_Pntr1](https://namemc.com/profile/_Pntr1.1)

