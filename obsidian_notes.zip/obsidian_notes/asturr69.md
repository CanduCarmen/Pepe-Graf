---
aliases: [asturr69]
tags: [minecraft, player]
connections: 2
namemc: https://namemc.com/profile/asturr69.1
---

# asturr69

[asturr69](https://namemc.com/profile/asturr69.1)

