---
aliases: [Sevetyan]
tags: [minecraft, player]
connections: 1
namemc: https://namemc.com/profile/Sevetyan.1
---

# Sevetyan

[Sevetyan](https://namemc.com/profile/Sevetyan.1)

