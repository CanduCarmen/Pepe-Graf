---
aliases: [yozha_mc]
tags: [minecraft, player]
connections: 3
namemc: https://namemc.com/profile/yozha_mc.1
---

# yozha_mc

[yozha_mc](https://namemc.com/profile/yozha_mc.1)

