---
aliases: [emortalmarcus]
tags: [minecraft, player]
connections: 1
namemc: https://namemc.com/profile/emortalmarcus.1
---

# emortalmarcus

[emortalmarcus](https://namemc.com/profile/emortalmarcus.1)

