---
aliases: [Viktiga]
tags: [minecraft, player]
connections: 1
namemc: https://namemc.com/profile/Viktiga.1
---

# Viktiga

[Viktiga](https://namemc.com/profile/Viktiga.1)

