---
aliases: [aisai_]
tags: [minecraft, player]
connections: 3
namemc: https://namemc.com/profile/aisai_.1
---

# aisai_

[aisai_](https://namemc.com/profile/aisai_.1)

![](https://s.namemc.com/3d/skin/body.png?id=b928f89ffe382128&model=slim&width=100&height=100)

## Связи

- Всего связей: 3
- Подписчиков: 1
- Подписок: 1

### Подписчики

- [[Insomni_a]]

### Подписки

- [[Insomni_a]]

