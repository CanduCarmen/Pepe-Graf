---
aliases: [grudei]
tags: [minecraft, player]
connections: 3
namemc: https://namemc.com/profile/grudei.1
---

# grudei

[grudei](https://namemc.com/profile/grudei.1)

