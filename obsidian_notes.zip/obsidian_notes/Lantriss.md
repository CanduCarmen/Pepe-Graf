---
aliases: [Lantriss]
tags: [minecraft, player]
connections: 2
namemc: https://namemc.com/profile/Lantriss.1
---

# Lantriss

[Lantriss](https://namemc.com/profile/Lantriss.1)

