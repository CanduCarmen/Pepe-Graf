---
aliases: [Stekerko]
tags: [minecraft, player]
connections: 2
namemc: https://namemc.com/profile/Stekerko.1
---

# Stekerko

[Stekerko](https://namemc.com/profile/Stekerko.1)

