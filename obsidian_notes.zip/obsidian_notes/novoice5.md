---
aliases: [novoice5]
tags: [minecraft, player]
connections: 7
namemc: https://namemc.com/profile/novoice5.1
---

# novoice5

[novoice5](https://namemc.com/profile/novoice5.1)

![](https://s.namemc.com/3d/skin/body.png?id=493d28d9c9cbf4ce&model=classic&width=100&height=100)

## Связи

- Всего связей: 7
- Подписчиков: 6
- Подписок: 1

### Подписчики

- [[M0r4r]]
- [[R_A_P_T_O_F]]
- [[Slovaric]]
- [[alifrostyk]]
- [[deadmag67]]
- [[tishinart]]

### Подписки

- [[Gandasina]]

