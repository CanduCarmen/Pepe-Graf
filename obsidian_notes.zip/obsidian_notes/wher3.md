---
aliases: [wher3]
tags: [minecraft, player]
connections: 9
namemc: https://namemc.com/profile/wher3.1
---

# wher3

[wher3](https://namemc.com/profile/wher3.1)

