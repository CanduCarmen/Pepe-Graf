---
aliases: [hosi_mi]
tags: [minecraft, player]
connections: 4
namemc: https://namemc.com/profile/hosi_mi.1
---

# hosi_mi

[hosi_mi](https://namemc.com/profile/hosi_mi.1)

![](https://s.namemc.com/3d/skin/body.png?id=4c2cb85b46156f6f&model=slim&width=100&height=100)

## Связи

- Всего связей: 4
- Подписчиков: 2
- Подписок: 2

### Подписчики

- [[Me_egorka]]
- [[nikitosik2007kl]]

### Подписки

- [[Me_egorka]]
- [[nikitosik2007kl]]

