---
aliases: [Yestes]
tags: [minecraft, player]
connections: 1
namemc: https://namemc.com/profile/Yestes.1
---

# Yestes

[Yestes](https://namemc.com/profile/Yestes.1)

