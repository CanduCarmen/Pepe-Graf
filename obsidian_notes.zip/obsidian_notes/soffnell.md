---
aliases: [soffnell]
tags: [minecraft, player]
connections: 2
namemc: https://namemc.com/profile/soffnell.1
---

# soffnell

[soffnell](https://namemc.com/profile/soffnell.1)

