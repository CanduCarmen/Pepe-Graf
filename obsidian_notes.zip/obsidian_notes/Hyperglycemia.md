---
aliases: [Hyperglycemia]
tags: [minecraft, player]
connections: 1
namemc: https://namemc.com/profile/Hyperglycemia.1
---

# Hyperglycemia

[Hyperglycemia](https://namemc.com/profile/Hyperglycemia.1)

