---
aliases: [5opka]
tags: [minecraft, player]
connections: 12
namemc: https://namemc.com/profile/5opka.1
---

# 5opka

[5opka](https://namemc.com/profile/5opka.1)

