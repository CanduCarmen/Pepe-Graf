---
aliases: [Leaning]
tags: [minecraft, player]
connections: 1
namemc: https://namemc.com/profile/Leaning.1
---

# Leaning

[Leaning](https://namemc.com/profile/Leaning.1)

