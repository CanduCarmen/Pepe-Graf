---
aliases: [Platinthenium]
tags: [minecraft, player]
connections: 1
namemc: https://namemc.com/profile/Platinthenium.1
---

# Platinthenium

[Platinthenium](https://namemc.com/profile/Platinthenium.1)

