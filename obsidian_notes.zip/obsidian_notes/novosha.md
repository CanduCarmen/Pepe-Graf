---
aliases: [novosha]
tags: [minecraft, player]
connections: 2
namemc: https://namemc.com/profile/novosha.1
---

# novosha

[novosha](https://namemc.com/profile/novosha.1)

