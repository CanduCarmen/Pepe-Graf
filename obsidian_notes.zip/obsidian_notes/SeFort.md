---
aliases: [SeFort]
tags: [minecraft, player]
connections: 25
namemc: https://namemc.com/profile/SeFort.1
github: https://github.com/sefort
steam: https://steamcommunity.com/id/sefort
twitch: https://twitch.tv/sef0rt
---

# SeFort

[SeFort](https://namemc.com/profile/SeFort.1)

![](https://s.namemc.com/3d/skin/body.png?id=900cf48c7cf1cc4b&model=slim&width=100&height=100)

## Соцсети

- [GH] github: [https://github.com/sefort](https://github.com/sefort)
- [ST] steam: [https://steamcommunity.com/id/sefort](https://steamcommunity.com/id/sefort)
- [TW] twitch: [https://twitch.tv/sef0rt](https://twitch.tv/sef0rt)

## Связи

- Всего связей: 25
- Подписчиков: 13
- Подписок: 12

### Подписчики

- [[AstronovaVT]]
- [[Fruik]]
- [[Hollow_Ink]]
- [[Korrrfy]]
- [[Krapiva]]
- [[NateShapiro]]
- [[S_meHa]]
- [[ShadowDemonHD]]
- [[V_A_A_R]]
- [[VePopo4ka]]
- [[draGun0f]]
- [[fisicpy]]
- [[tewizoff]]

### Подписки

- [[Defom_kills]]
- [[Hollow_Ink]]
- [[Katulhu_]]
- [[Krapiva]]
- [[Mlk_Reski]]
- [[MrFlint]]
- [[NateShapiro]]
- [[ReDexTop]]
- [[ShadowDemonHD]]
- [[Shredinger]]
- [[Toadstired]]
- [[V_A_A_R]]

