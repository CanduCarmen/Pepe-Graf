---
aliases: [Sempervirent]
tags: [minecraft, player]
connections: 3
namemc: https://namemc.com/profile/Sempervirent.1
---

# Sempervirent

[Sempervirent](https://namemc.com/profile/Sempervirent.1)

![](https://s.namemc.com/3d/skin/body.png?id=d2d836b306a8f5e3&model=classic&width=100&height=100)

## Связи

- Всего связей: 3
- Подписчиков: 1
- Подписок: 1

### Подписчики

- [[Trialogue]]

### Подписки

- [[Trialogue]]

