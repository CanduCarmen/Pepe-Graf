---
aliases: [lusiz]
tags: [minecraft, player]
connections: 5
namemc: https://namemc.com/profile/lusiz.1
---

# lusiz

[lusiz](https://namemc.com/profile/lusiz.1)

