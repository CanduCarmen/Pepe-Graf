---
aliases: [solarwavez]
tags: [minecraft, player]
connections: 1
namemc: https://namemc.com/profile/solarwavez.1
---

# solarwavez

[solarwavez](https://namemc.com/profile/solarwavez.1)

