---
aliases: [chapnur]
tags: [minecraft, player]
connections: 2
namemc: https://namemc.com/profile/chapnur.1
---

# chapnur

[chapnur](https://namemc.com/profile/chapnur.1)

