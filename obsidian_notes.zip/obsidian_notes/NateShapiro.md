---
aliases: [NateShapiro]
tags: [minecraft, player]
connections: 7
namemc: https://namemc.com/profile/NateShapiro.1
---

# NateShapiro

[NateShapiro](https://namemc.com/profile/NateShapiro.1)

